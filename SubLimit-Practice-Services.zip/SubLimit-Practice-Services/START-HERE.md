# Services practice set: facilities maintenance order

Practice with fictional records before using your own. Every company, person, identifier, evidence reference and amount in this folder is invented. Nothing in this sample establishes the facts of a real contract. Do not submit the sample reports.

The sample is a small services contractor, Fictional Facilities Maintenance Co., working on order FAC-DEMO-002 for October 2026. Its result is compliant but closer to the 50% services limit than the first practice set.

## 1. Open a practice workspace

Extract the entire practice ZIP to a local folder. In SubLimit, choose Overview → Choose workspace and select a new, empty folder, for example SubLimit Services Practice. Keep it separate from your business records and from the first practice set.

## 2. Load the sample

Choose Overview → Open configuration and select contract.json from this folder.

- Contract setup: FAC-DEMO-002, reporting month 2026-10, category services, NAICS 561210, compliance period 2026-10-01 to 2026-10-31 (order basis). The confirmations and evidence references are fictional.
- People & vendors: 7 employees and 4 subcontractors.
  - Fictional Mechanical Services LLC (V301): verified not similarly situated
  - Sample Janitorial Partners LLC (V302): verified similarly situated
  - Example Grounds Independent (IC301): independent contractor, verified not similarly situated
  - Demo Elevator Care Inc (V303): verified not similarly situated
- Government receipts: G201 $72,400.00 and G202 $68,150.00, total $140,550.00.

## 3. Import the spreadsheets

Under Import & mapping, select payroll.xlsx for payroll/timekeeping and subcontractors.xlsx for subcontractors. Keep the mappings loaded from contract.json. Choose Import and calculate.

The files deliberately include rows that must not be counted:

- P108: payroll for another job (FAC-OTHER-009), excluded as other contract
- S105: a payment on another job (FAC-OTHER-009), excluded as other contract
- S106: a November payment, excluded as outside the period

Results → View all source rows shows each row's disposition.

## 4. Check the result

Expected result, produced by SubLimit's engine on these files:

| Item | Value |
| --- | ---: |
| Status | COMPLIANT (final period) |
| Eligible Government payments | $140,550.00 |
| Counted subcontracting | $59,150.00 |
| Percentage | 42.084667% |
| Limit / warning margin | 50.00% / 5.00 percentage points |

The counted $59,150.00 consists of:

| Record | Vendor | Counted | Treatment |
| --- | --- | ---: | --- |
| S101 | Fictional Mechanical Services LLC | $38,600.00 | Non-SSE payment |
| S102 | Sample Janitorial Partners LLC | $3,500.00 | Further subcontracting by the SSE (of a $21,000.00 payment) |
| S103 | Example Grounds Independent | $6,800.00 | Non-SSE payment (independent contractor) |
| S104 | Demo Elevator Care Inc | $10,250.00 | Non-SSE payment |

Workforce totals: 7 prime employees, 928 prime hours, $26,176.00 prime labor cost, 650 subcontractor hours, $76,650.00 subcontractor payments in October. This sample has no open exceptions; review Exceptions anyway.

At 42.084667%, the sample is about 7.9 percentage points under the limit: 50% of $140,550.00 is $70,275.00, which is $11,125.00 more than the counted amount.

## 5. Prepare the workforce draft

With the result selected, open OCC workforce report → Import staffing file and select staffing.json. Expect 13 worker lines (7 prime, 6 subcontractor workers) totaling 1,578 hours, all imported hours reconciled, and no items needing attention. Export unsigned Word draft to a new local folder and inspect every page. Workforce hours and the officer's certification are separate from the FAR payment calculation. Do not sign or submit this fictional draft.

## Quick checklist

- [ ] Separate practice workspace selected
- [ ] Contract, people & vendors and receipts reviewed
- [ ] Both spreadsheets imported; excluded rows checked under View all source rows
- [ ] $59,150.00 and 42.084667% checked against $140,550.00
- [ ] Workforce draft reviewed: 13 lines, 1,578 hours

The checklist records your progress, not compliance approval.

Need help? Contact support@getsublimit.com. Describe the step using these fictional examples; do not send confidential workforce files or passwords.
